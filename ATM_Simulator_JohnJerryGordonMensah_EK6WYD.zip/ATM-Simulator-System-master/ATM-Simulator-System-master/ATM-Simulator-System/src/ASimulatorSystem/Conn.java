package ASimulatorSystem;

import java.sql.*;

public class Conn {
    public Connection conn;
    public Statement s;

    public Conn() {
        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/bankmanagementsystem",
                "root",
                "your_actual_password" // Replace with your real MySQL password
            );

            // Create statement
            s = conn.createStatement();

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database connection failed.");
            e.printStackTrace();
        }

        // Optional: fail fast if connection is null
        if (conn == null) {
            throw new RuntimeException("Connection object is null. Check database settings.");
        }
    }

    // Optional: helper method to get connection
    public Connection getConnection() {
        return conn;
    }
}
